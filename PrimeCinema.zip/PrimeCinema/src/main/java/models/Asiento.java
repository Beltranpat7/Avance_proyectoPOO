package models;

public class Asiento {
    private int idAsiento;
    private String nombreAsiento;
    private int idSala;

    // Getters y setters
    public int getIdAsiento() {
        return idAsiento;
    }

    public void setIdAsiento(int idAsiento) {
        this.idAsiento = idAsiento;
    }

    public String getNombreAsiento() {
        return nombreAsiento;
    }

    public void setNombreAsiento(String nombreAsiento) {
        this.nombreAsiento = nombreAsiento;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    @Override
    public String toString() {
        return "Asiento [idAsiento=" + idAsiento + ", nombreAsiento=" + nombreAsiento + ", idSala=" + idSala + "]";
    }
}
