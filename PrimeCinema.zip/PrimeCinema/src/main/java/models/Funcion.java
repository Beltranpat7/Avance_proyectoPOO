package models;

import java.sql.Timestamp;

public class Funcion {
    private int idFuncion;
    private Timestamp fechaHoraInicio;
    private Timestamp fechaHoraFin;
    private int idPrecio;
    private int idSala;
    private int idPelicula;

    // Atributos relacionados a la película
    private String nombrePelicula;
    private float duracionPelicula;
    private int idGeneroPelicula;
    private String nombreGeneroPelicula;
    private int idFormatoPelicula;
    private String nombreFormatoPelicula;
    private int idClasificacionPelicula;
    private String nombreClasificacionPelicula;

    // Getters y setters

    public int getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }

    public Timestamp getFechaHoraInicio() {
        return fechaHoraInicio;
    }

    public void setFechaHoraInicio(Timestamp fechaHoraInicio) {
        this.fechaHoraInicio = fechaHoraInicio;
    }

    public Timestamp getFechaHoraFin() {
        return fechaHoraFin;
    }

    public void setFechaHoraFin(Timestamp fechaHoraFin) {
        this.fechaHoraFin = fechaHoraFin;
    }

    public int getIdPrecio() {
        return idPrecio;
    }

    public void setIdPrecio(int idPrecio) {
        this.idPrecio = idPrecio;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public String getNombrePelicula() {
        return nombrePelicula;
    }

    public void setNombrePelicula(String nombrePelicula) {
        this.nombrePelicula = nombrePelicula;
    }

    public float getDuracionPelicula() {
        return duracionPelicula;
    }

    public void setDuracionPelicula(float duracionPelicula) {
        this.duracionPelicula = duracionPelicula;
    }

    public int getIdGeneroPelicula() {
        return idGeneroPelicula;
    }

    public void setIdGeneroPelicula(int idGeneroPelicula) {
        this.idGeneroPelicula = idGeneroPelicula;
    }

    public String getNombreGeneroPelicula() {
        return nombreGeneroPelicula;
    }

    public void setNombreGeneroPelicula(String nombreGeneroPelicula) {
        this.nombreGeneroPelicula = nombreGeneroPelicula;
    }

    public int getIdFormatoPelicula() {
        return idFormatoPelicula;
    }

    public void setIdFormatoPelicula(int idFormatoPelicula) {
        this.idFormatoPelicula = idFormatoPelicula;
    }

    public String getNombreFormatoPelicula() {
        return nombreFormatoPelicula;
    }

    public void setNombreFormatoPelicula(String nombreFormatoPelicula) {
        this.nombreFormatoPelicula = nombreFormatoPelicula;
    }

    public int getIdClasificacionPelicula() {
        return idClasificacionPelicula;
    }

    public void setIdClasificacionPelicula(int idClasificacionPelicula) {
        this.idClasificacionPelicula = idClasificacionPelicula;
    }

    public String getNombreClasificacionPelicula() {
        return nombreClasificacionPelicula;
    }

    public void setNombreClasificacionPelicula(String nombreClasificacionPelicula) {
        this.nombreClasificacionPelicula = nombreClasificacionPelicula;
    }

    @Override
    public String toString() {
        return "Funcion [idFuncion=" + idFuncion + ", fechaHoraInicio=" + fechaHoraInicio + ", fechaHoraFin=" + fechaHoraFin
                + ", idPrecio=" + idPrecio + ", idSala=" + idSala + ", idPelicula=" + idPelicula + ", nombrePelicula="
                + nombrePelicula + ", duracionPelicula=" + duracionPelicula + ", idGeneroPelicula=" + idGeneroPelicula
                + ", nombreGeneroPelicula=" + nombreGeneroPelicula + ", idFormatoPelicula=" + idFormatoPelicula
                + ", nombreFormatoPelicula=" + nombreFormatoPelicula + ", idClasificacionPelicula=" + idClasificacionPelicula
                + ", nombreClasificacionPelicula=" + nombreClasificacionPelicula + "]";
    }
}
