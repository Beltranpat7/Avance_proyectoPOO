package models;

public class EstadoUsuario {
    private int id;
    private String nombreEstadoU;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreEstadoU() {
        return nombreEstadoU;
    }

    public void setNombreEstadoU(String nombreEstadoU) {
        this.nombreEstadoU = nombreEstadoU;
    }
}
