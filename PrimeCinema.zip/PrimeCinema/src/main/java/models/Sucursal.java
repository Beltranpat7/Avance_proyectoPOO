package models;

public class Sucursal {
    private int idSucursal;
    private String nombreSucursal;
    private String direccion;
    private String telefono;
    private int idUsuario;

    public int getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }

    public String getNombreSucursal() {
        return nombreSucursal;
    }

    public void setNombreSucursal(String nombreSucursal) {
        this.nombreSucursal = nombreSucursal;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @Override
    public String toString() {
        return "Sucursal [idSucursal=" + idSucursal + ", nombreSucursal=" + nombreSucursal + ", direccion=" + direccion
                + ", telefono=" + telefono + ", idUsuario=" + idUsuario + "]";
    }
}
