package models;

public class Entrada {
    private int idEntrada;
    private int idFuncion;
    private int idAsiento;
    private int idUsuario;

    public int getIdEntrada() {
        return idEntrada;
    }

    public void setIdEntrada(int idEntrada) {
        this.idEntrada = idEntrada;
    }

    public int getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }

    public int getIdAsiento() {
        return idAsiento;
    }

    public void setIdAsiento(int idAsiento) {
        this.idAsiento = idAsiento;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @Override
    public String toString() {
        return "Entrada [idEntrada=" + idEntrada + ", idFuncion=" + idFuncion + ", idAsiento=" + idAsiento
                + ", idUsuario=" + idUsuario + "]";
    }
}
