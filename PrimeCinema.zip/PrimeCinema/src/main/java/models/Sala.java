package models;

public class Sala {
    private static int idSala;
    private String nombreSala;
    private int idSucursal;

    public static int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    public String getNombreSala() {
        return nombreSala;
    }

    public void setNombreSala(String nombreSala) {
        this.nombreSala = nombreSala;
    }

    public int getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }

    @Override
    public String toString() {
        return "Sala [idSala=" + idSala + ", nombreSala=" + nombreSala + ", idSucursal=" + idSucursal + "]";
    }
}

