package models;

import java.util.Date;

public class Facturacion {
    private int idFacturacion;
    private Date horaEmision;
    private double total;
    private int idPelicula;
    private int idFuncion;
    private int idSucursal;

    public Facturacion(int idFacturacion, Date horaEmision, double total, int idPelicula, int idFuncion, int idSucursal) {
        this.idFacturacion = idFacturacion;
        this.horaEmision = horaEmision;
        this.total = total;
        this.idPelicula = idPelicula;
        this.idFuncion = idFuncion;
        this.idSucursal = idSucursal;
    }

    public int getIdFacturacion() {
        return idFacturacion;
    }

    public void setIdFacturacion(int idFacturacion) {
        this.idFacturacion = idFacturacion;
    }

    public Date getHoraEmision() {
        return horaEmision;
    }

    public void setHoraEmision(Date horaEmision) {
        this.horaEmision = horaEmision;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getIdPelicula() {
        return idPelicula;
    }

    public void setIdPelicula(int idPelicula) {
        this.idPelicula = idPelicula;
    }

    public int getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(int idFuncion) {
        this.idFuncion = idFuncion;
    }

    public int getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }

    @Override
    public String toString() {
        return "Facturacion [idFacturacion=" + idFacturacion + ", horaEmision=" + horaEmision + ", total=" + total
                + ", idPelicula=" + idPelicula + ", idFuncion=" + idFuncion + ", idSucursal=" + idSucursal + "]";
    }
}
