package services;

import models.Asiento;
import com.example.primecinema.db.DatabaseConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AsientoService {

    public boolean registrarAsiento(Asiento asiento) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();
        String query = "INSERT INTO asientos (nombre_asiento, id_sala) VALUES (?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, asiento.getNombreAsiento());
            preparedStatement.setInt(2, asiento.getIdSala());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
