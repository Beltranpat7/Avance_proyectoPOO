package services;

import com.example.primecinema.db.DatabaseConnector;
import models.Clasificacion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClasificacionService {

    public List<Map<String, Object>> obtenerClasificacionesDesdeBD() {
        List<Map<String, Object>> clasificaciones = new ArrayList<>();

        DatabaseConnector connector = new DatabaseConnector();
        Connection conn = connector.getConnection();

        if (conn != null) {
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                String sql = "SELECT id_clasificacion, nombre_clasificacion FROM clasificacion";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    int idClasificacion = rs.getInt("id_clasificacion");
                    String nombreClasificacion = rs.getString("nombre_clasificacion");

                    // Crear un mapa con el ID y nombre de la clasificación y agregarlo a la lista
                    Map<String, Object> clasificacionMap = new HashMap<>();
                    clasificacionMap.put("id", idClasificacion);
                    clasificacionMap.put("nombre", nombreClasificacion);

                    clasificaciones.add(clasificacionMap);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        }

        return clasificaciones;
    }
}
