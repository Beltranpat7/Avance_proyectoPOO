package services;

import com.example.primecinema.db.DatabaseConnector;
import models.Sala;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SalaService {

    public boolean registrarSala(Sala sala) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();
        String query = "INSERT INTO salas (nombre_sala, id_sucursal) VALUES (?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, sala.getNombreSala());
            preparedStatement.setInt(2, sala.getIdSucursal());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
