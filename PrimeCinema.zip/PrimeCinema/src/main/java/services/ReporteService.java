package services;

import models.Reporte;
import models.Sala;
import models.Funcion;
import models.Entrada;
import models.Facturacion;
import com.example.primecinema.db.DatabaseConnector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReporteService {

    // Simulación de la base de datos
    private List<Sala> salas;
    private List<Funcion> funciones;
    private List<Entrada> entradas;
    private List<Facturacion> facturaciones;

    public ReporteService(List<Sala> salas, List<Funcion> funciones, List<Entrada> entradas, List<Facturacion> facturaciones) {
        this.salas = salas;
        this.funciones = funciones;
        this.entradas = entradas;
        this.facturaciones = facturaciones;
    }

    public List<Reporte> obtenerSalasPorEntradasVendidas() {
        Map<Integer, Integer> entradasPorSala = new HashMap<>();

        // Contar la cantidad de entradas por sala
        for (Entrada entrada : entradas) {
            int idSala = Sala.getIdSala();
            entradasPorSala.put(idSala, entradasPorSala.getOrDefault(idSala, 0) + 1);
        }

        // Convertir a objetos Reporte
        List<Reporte> reportes = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : entradasPorSala.entrySet()) {
            int idSala = entry.getKey();
            int cantidad = entry.getValue();
            Sala sala = encontrarSalaPorId(idSala);

            if (sala != null) {
                Reporte reporte = new Reporte(sala.getNombreSala(), cantidad);
                reportes.add(reporte);
            }
        }

        return reportes;
    }

    public Reporte obtenerSucursalConMayoresIngresos() {
        Map<Integer, Double> ingresosPorSucursal = new HashMap<>();

        // Calcular ingresos por sucursal
        for (Facturacion facturacion : facturaciones) {
            int idSucursal = facturacion.getIdSucursal();
            double total = facturacion.getTotal();
            ingresosPorSucursal.put(idSucursal, ingresosPorSucursal.getOrDefault(idSucursal, 0.0) + total);
        }

        // Encontrar la sucursal con mayores ingresos
        int idSucursalMax = -1;
        double maxIngresos = 0.0;

        for (Map.Entry<Integer, Double> entry : ingresosPorSucursal.entrySet()) {
            int idSucursal = entry.getKey();
            double ingresos = entry.getValue();

            if (ingresos > maxIngresos) {
                maxIngresos = ingresos;
                idSucursalMax = idSucursal;
            }
        }

        // Convertir a objeto Reporte
        if (idSucursalMax != -1) {
            String nombreSucursal = encontrarNombreSucursalPorId(idSucursalMax);
            return new Reporte(nombreSucursal, maxIngresos);
        } else {
            return null;
        }
    }

    // Métodos de utilidad para encontrar información en las listas simuladas
    private Sala encontrarSalaPorId(int idSala) {
        for (Sala sala : salas) {
            if (sala.getIdSala() == idSala) {
                return sala;
            }
        }
        return null;
    }

    private String encontrarNombreSucursalPorId(int idSucursal) {
        String nombreSucursal = null;

        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "SELECT nombre_sucursal FROM sucursales WHERE id_sucursal = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idSucursal);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                nombreSucursal = resultSet.getString("nombre_sucursal");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return nombreSucursal;
    }
}
