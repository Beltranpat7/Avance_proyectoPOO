package services;

import models.Funcion;
import com.example.primecinema.db.DatabaseConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FuncionService {

    public List<Funcion> buscarFuncionesPorSucursal(String nombreSucursal) {
        List<Funcion> funciones = new ArrayList<>();
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "SELECT * FROM funcion f " +
                "JOIN salas s ON f.id_sala = s.id_sala " +
                "JOIN sucursales su ON s.id_sucursal = su.id_sucursal " +
                "JOIN peliculas p ON f.id_pelicula = p.id_pelicula " +
                "JOIN genero_pelicula gp ON p.id_genero = gp.id_genero " +
                "JOIN formato fo ON p.id_formato = fo.id_formato " +
                "JOIN clasificacion c ON p.id_clasificacion = c.id_clasificacion " +
                "WHERE su.nombre_sucursal = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nombreSucursal);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Funcion funcion = new Funcion();
                funcion.setIdFuncion(resultSet.getInt("id_funcion"));
                funcion.setFechaHoraInicio(resultSet.getTimestamp("Fecha_hora_inicio"));
                funcion.setFechaHoraFin(resultSet.getTimestamp("Fecha_hora_fin"));
                funcion.setIdPrecio(resultSet.getInt("id_precio"));
                funcion.setIdSala(resultSet.getInt("id_sala"));
                funcion.setIdPelicula(resultSet.getInt("id_pelicula"));

                // Atributos relacionados a la película
                funcion.setNombrePelicula(resultSet.getString("nombre"));
                funcion.setDuracionPelicula(resultSet.getFloat("duracion"));
                funcion.setIdGeneroPelicula(resultSet.getInt("id_genero"));
                funcion.setNombreGeneroPelicula(resultSet.getString("nombre_genero"));
                funcion.setIdFormatoPelicula(resultSet.getInt("id_formato"));
                funcion.setNombreFormatoPelicula(resultSet.getString("nombre_formato"));
                funcion.setIdClasificacionPelicula(resultSet.getInt("id_clasificacion"));
                funcion.setNombreClasificacionPelicula(resultSet.getString("nombre_clasificacion"));

                funciones.add(funcion);
            }

            return funciones;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Funcion> buscarFuncionesPorPelicula(String nombrePelicula) {
        List<Funcion> funciones = new ArrayList<>();
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();
        String query = "SELECT * FROM funcion f " +
                "JOIN peliculas p ON f.id_pelicula = p.id_pelicula " +
                "JOIN genero_pelicula gp ON p.id_genero = gp.id_genero " +
                "JOIN formato fo ON p.id_formato = fo.id_formato " +
                "JOIN clasificacion c ON p.id_clasificacion = c.id_clasificacion " +
                "WHERE p.nombre = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nombrePelicula);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Funcion funcion = new Funcion();
                funcion.setIdFuncion(resultSet.getInt("id_funcion"));
                funcion.setFechaHoraInicio(resultSet.getTimestamp("Fecha_hora_inicio"));
                funcion.setFechaHoraFin(resultSet.getTimestamp("Fecha_hora_fin"));
                funcion.setIdPrecio(resultSet.getInt("id_precio"));
                funcion.setIdSala(resultSet.getInt("id_sala"));
                funcion.setIdPelicula(resultSet.getInt("id_pelicula"));

                // Atributos relacionados a la película
                funcion.setNombrePelicula(resultSet.getString("nombre"));
                funcion.setDuracionPelicula(resultSet.getFloat("duracion"));
                funcion.setIdGeneroPelicula(resultSet.getInt("id_genero"));
                funcion.setNombreGeneroPelicula(resultSet.getString("nombre_genero"));
                funcion.setIdFormatoPelicula(resultSet.getInt("id_formato"));
                funcion.setNombreFormatoPelicula(resultSet.getString("nombre_formato"));
                funcion.setIdClasificacionPelicula(resultSet.getInt("id_clasificacion"));
                funcion.setNombreClasificacionPelicula(resultSet.getString("nombre_clasificacion"));

                funciones.add(funcion);
            }

            return funciones;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
