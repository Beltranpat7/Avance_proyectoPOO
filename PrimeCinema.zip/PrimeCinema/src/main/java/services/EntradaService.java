package services;

import models.Entrada;
import com.example.primecinema.db.DatabaseConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EntradaService {

    public boolean registrarEntrdada(Entrada entrada) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "INSERT INTO entradas (id_funcion, id_asiento, id_usuario) VALUES (?, ?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, entrada.getIdFuncion());
            preparedStatement.setInt(2, entrada.getIdAsiento());
            preparedStatement.setInt(3, entrada.getIdUsuario());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepciones, puedes hacer algo diferente aquí
            return false;
        }
    }
}

