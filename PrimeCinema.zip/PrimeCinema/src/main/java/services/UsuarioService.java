package services;

import models.EstadoUsuario;
import models.Usuario;
import com.example.primecinema.db.DatabaseConnector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioService {

    // Método para registrar un nuevo usuario
    public boolean registrarUsuario(Usuario usuario) {
        // Obtener el estado de usuario "Activo" de la base de datos
        EstadoUsuario estadoActivo = obtenerEstadoUsuarioPorId(1); // Suponiendo que 1 es el ID para "Activo"

        // Asignar el estado de usuario "Activo" al nuevo usuario
        usuario.setIdEstadoUsuario(estadoActivo.getId());

        // Guardar el usuario en la base de datos (suponiendo que hay un método para hacerlo)
        boolean registroExitoso = guardarUsuarioEnBaseDeDatos(usuario);

        return registroExitoso;
    }

    public boolean guardarUsuarioEnBaseDeDatos(Usuario usuario) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "INSERT INTO usuario (nombre, apellido, dui, direccion, numero_telefono, correo_electronico, contraseña, id_estadoUsuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, usuario.getNombre());
            preparedStatement.setString(2, usuario.getApellido());
            preparedStatement.setString(3, usuario.getDui());
            preparedStatement.setString(4, usuario.getDireccion());
            preparedStatement.setString(5, usuario.getNumeroTelefono());
            preparedStatement.setString(6, usuario.getCorreoElectronico());
            preparedStatement.setString(7, usuario.getContrasena());
            preparedStatement.setInt(8, usuario.getIdEstadoUsuario());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Método para autenticar un usuario por correo electrónico y contraseña
    public Usuario autenticarUsuario(String correoElectronico, String contrasena) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "SELECT * FROM usuario WHERE correo_electronico = ? AND contraseña = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, correoElectronico);
            preparedStatement.setString(2, contrasena);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(resultSet.getInt("id_usuario"));
                usuario.setNombre(resultSet.getString("nombre"));
                usuario.setApellido(resultSet.getString("apellido"));
                usuario.setDui(resultSet.getString("dui"));
                usuario.setDireccion(resultSet.getString("direccion"));
                usuario.setNumeroTelefono(resultSet.getString("numero_telefono"));
                usuario.setCorreoElectronico(resultSet.getString("correo_electronico"));
                usuario.setContrasena(resultSet.getString("contraseña"));
                usuario.setIdEstadoUsuario(resultSet.getInt("id_estadoUsuario"));

                return usuario;
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean validarExistenciaEstadoUsuario(int idEstadoUsuario) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "SELECT COUNT(*) FROM estado_usuario WHERE id_estadoUsuario = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idEstadoUsuario);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public EstadoUsuario obtenerEstadoUsuarioPorId(int idEstadoUsuario) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "SELECT * FROM estado_usuario WHERE id_estadoUsuario = ?";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, idEstadoUsuario);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                EstadoUsuario estadoUsuario = new EstadoUsuario();
                estadoUsuario.setId(resultSet.getInt("id_estadoUsuario"));
                estadoUsuario.setNombreEstadoU(resultSet.getString("nombre_estadoU"));
                return estadoUsuario;
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }


    }

    public List<Integer> obtenerIdsUsuariosDesdeBD() {
        List<Integer> idsUsuarios = new ArrayList<>();

        DatabaseConnector connector = new DatabaseConnector();
        Connection conn = connector.getConnection();

        if (conn != null) {
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                String sql = "SELECT id_usuario FROM Usuario";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    int idUsuario = rs.getInt("id_usuario");
                    idsUsuarios.add(idUsuario);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        }

        return idsUsuarios;
    }

    public String obtenerIdsUsuariosComoJson() {
        List<Integer> idsUsuarios = obtenerIdsUsuariosDesdeBD();

        // Convertir la lista de IDs a formato JSON
        StringBuilder jsonBuilder = new StringBuilder();
        jsonBuilder.append("{ \"idsUsuarios\": [");
        for (int i = 0; i < idsUsuarios.size(); i++) {
            jsonBuilder.append(idsUsuarios.get(i));
            if (i < idsUsuarios.size() - 1) {
                jsonBuilder.append(",");
            }
        }
        jsonBuilder.append("] }");

        return jsonBuilder.toString();
    }
}