package services;

import com.example.primecinema.db.DatabaseConnector;
import models.Pelicula;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PeliculaService {

    public boolean registrarPelicula(Pelicula pelicula) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();
        String query = "INSERT INTO peliculas (nombre, duracion, id_genero, id_formato, id_clasificacion) VALUES (?, ?, ?, ?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, pelicula.getNombre());
            preparedStatement.setFloat(2, pelicula.getDuracion());
            preparedStatement.setInt(3, pelicula.getIdGenero());
            preparedStatement.setInt(4, pelicula.getIdFormato());
            preparedStatement.setInt(5, pelicula.getIdClasificacion());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
