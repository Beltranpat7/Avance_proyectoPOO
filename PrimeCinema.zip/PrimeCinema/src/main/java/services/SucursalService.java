package services;

import com.example.primecinema.db.DatabaseConnector;
import models.Sucursal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SucursalService {
    public boolean registrarSucursal(Sucursal sucursal) {
        DatabaseConnector connector = new DatabaseConnector();
        Connection connection = connector.getConnection();

        String query = "INSERT INTO Sucursales (nombre_sucursal, direccion, telefono, id_usuario) VALUES (?, ?, ?, ?)";

        try (
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, sucursal.getNombreSucursal());
            preparedStatement.setString(2, sucursal.getDireccion());
            preparedStatement.setString(3, sucursal.getTelefono());
            preparedStatement.setInt(4, sucursal.getIdUsuario());

            int filasAfectadas = preparedStatement.executeUpdate();

            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public List<Map<String, Object>> obtenerSucursalesDesdeBD() {
        List<Map<String, Object>> sucursales = new ArrayList<>();

        DatabaseConnector connector = new DatabaseConnector();
        Connection conn = connector.getConnection();

        if (conn != null) {
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                String sql = "SELECT id_sucursal, nombre_sucursal FROM sucursales";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    int idSucursal = rs.getInt("id_sucursal");
                    String nombreSucursal = rs.getString("nombre_sucursal");

                    // Crear un mapa con el ID y nombre de la sucursal y agregarlo a la lista
                    Map<String, Object> sucursalMap = new HashMap<>();
                    sucursalMap.put("id", idSucursal);
                    sucursalMap.put("nombre", nombreSucursal);

                    sucursales.add(sucursalMap);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        }

        return sucursales;
    }
    public Integer obtenerIdSucursalPorNombre(String nombreSucursal) {
        Integer idSucursal = null;

        // Implementa la lógica para obtener el ID de la sucursal dado su nombre
        DatabaseConnector connector = new DatabaseConnector();
        Connection conn = connector.getConnection();

        if (conn != null) {
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                String sql = "SELECT id_sucursal FROM Sucursales WHERE nombre_sucursal = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, nombreSucursal);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idSucursal = rs.getInt("id_sucursal");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        }

        return idSucursal;
    }

}
