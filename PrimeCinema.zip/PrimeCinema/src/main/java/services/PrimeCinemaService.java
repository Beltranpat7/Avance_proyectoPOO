package services;

public class PrimeCinemaService {
}
