package services;

import models.Facturacion;

import java.util.ArrayList;
import java.util.List;

public class FacturacionService {

    private List<Facturacion> facturaciones = new ArrayList<>();
    private int idCounter = 1;

    public boolean registrarFacturacion(Facturacion facturacion) {
        facturacion.setIdFacturacion(idCounter++);
        return facturaciones.add(facturacion);
    }

    public List<Facturacion> obtenerFacturaciones() {
        return new ArrayList<>(facturaciones);
    }
}

