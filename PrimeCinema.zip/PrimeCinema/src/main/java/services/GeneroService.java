package services;

import com.example.primecinema.db.DatabaseConnector;
import models.Genero;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GeneroService {

    public List<Map<String, Object>> obtenerGenerosDesdeBD() {
        List<Map<String, Object>> generos = new ArrayList<>();

        DatabaseConnector connector = new DatabaseConnector();
        Connection conn = connector.getConnection();

        if (conn != null) {
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                String sql = "SELECT id_genero, nombre_genero FROM genero_pelicula";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    int idGenero = rs.getInt("id_genero");
                    String nombreGenero = rs.getString("nombre_genero");

                    // Crear un mapa con el ID y nombre del género y agregarlo a la lista
                    Map<String, Object> generoMap = new HashMap<>();
                    generoMap.put("id", idGenero);
                    generoMap.put("nombre", nombreGenero);

                    generos.add(generoMap);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        }

        return generos;
    }
}


