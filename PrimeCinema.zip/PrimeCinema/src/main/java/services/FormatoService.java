package services;

import com.example.primecinema.db.DatabaseConnector;
import models.Formato;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FormatoService {

    public List<Map<String, Object>> obtenerFormatosDesdeBD() {
        List<Map<String, Object>> formatos = new ArrayList<>();

        DatabaseConnector connector = new DatabaseConnector();
        Connection conn = connector.getConnection();

        if (conn != null) {
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                String sql = "SELECT id_formato, nombre_formato FROM formato";
                stmt = conn.prepareStatement(sql);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    int idFormato = rs.getInt("id_formato");
                    String nombreFormato = rs.getString("nombre_formato");

                    // Crear un mapa con el ID y nombre del formato y agregarlo a la lista
                    Map<String, Object> formatoMap = new HashMap<>();
                    formatoMap.put("id", idFormato);
                    formatoMap.put("nombre", nombreFormato);

                    formatos.add(formatoMap);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        }

        return formatos;
    }
}
