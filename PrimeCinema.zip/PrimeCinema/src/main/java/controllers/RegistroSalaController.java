package controllers;

import models.Sala;
import services.SucursalService;
import services.SalaService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/RegistroSalaController")
public class RegistroSalaController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        SucursalService sucursalService = new SucursalService();
        List<Map<String, Object>> sucursales = sucursalService.obtenerSucursalesDesdeBD();
        request.setAttribute("sucursales", sucursales);
        request.getRequestDispatcher("registroSala.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombreSala = request.getParameter("nombreSala");
        String idSucursal = request.getParameter("idSucursal"); // Cambiado a recibir el ID directamente

        try {
            // Verificar si se proporcionó un ID de sucursal
            if (idSucursal != null && !idSucursal.isEmpty()) {
                Sala sala = new Sala();
                sala.setNombreSala(nombreSala);
                sala.setIdSucursal(Integer.parseInt(idSucursal)); // Convertir a entero y establecer el ID de la sucursal

                SalaService salaService = new SalaService();
                boolean registroExitoso = salaService.registrarSala(sala);

                if (registroExitoso) {
                    response.sendRedirect("inicio.jsp"); // Redirige a la página principal si el registro fue exitoso
                    return;
                }
            } else {
                // Si llegamos aquí, no se proporcionó un ID de sucursal
                System.out.println("Error: No se proporcionó un ID de sucursal.");
            }
        } catch (Exception e) {
            // Manejo genérico de excepciones, imprime el stack trace
            e.printStackTrace();
        }

        // Si llegamos aquí, hubo un error en el registro
        response.sendRedirect("registrarSala.jsp"); // Vuelve a la página de registro en caso de error
    }
}
