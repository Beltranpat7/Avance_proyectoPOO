package controllers;

public class VentaController {
}
