package controllers;

import models.Usuario;
import services.UsuarioService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("/InicioSesionController")
public class InicioSesionController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String correoElectronico = request.getParameter("correoElectronico");
        String contrasena = request.getParameter("contrasena");

        UsuarioService usuarioService = new UsuarioService();
        Usuario usuario = usuarioService.autenticarUsuario(correoElectronico, contrasena);

        if (usuario != null) {
            // Inicio de sesión exitoso
            // Aquí puedes redirigir a la página de inicio o hacer lo que necesites
            response.sendRedirect("inicio.jsp");
        } else {
            // La autenticación falló, puedes mostrar un mensaje de error
            request.setAttribute("error", "Correo electrónico o contraseña incorrectos");
            request.getRequestDispatcher("iniciarSesion.jsp").forward(request, response);
        }
    }
}
