package controllers;

import services.UsuarioService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/ObtenerIdsUsuariosController")
public class ObtenerIdsUsuariosController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener la lista de IDs de usuarios (gerentes) desde el servicio
        UsuarioService usuarioService = new UsuarioService();
        String jsonIdsUsuarios = usuarioService.obtenerIdsUsuariosComoJson();

        // Configurar la respuesta
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Enviar la lista de IDs como respuesta
        response.getWriter().write(jsonIdsUsuarios);
    }
}
