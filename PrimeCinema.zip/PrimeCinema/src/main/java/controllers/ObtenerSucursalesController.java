package controllers;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.SucursalService;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet("/ObtenerSucursalesServlet")
public class ObtenerSucursalesController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener la lista de sucursales desde el servicio
        SucursalService sucursalService = new SucursalService();
        List<Map<String, Object>> sucursales = sucursalService.obtenerSucursalesDesdeBD();

        // Convertir la lista de sucursales a formato JSON
        Gson gson = new Gson();
        String sucursalesJson = gson.toJson(sucursales);

        // Configurar la respuesta
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(sucursalesJson);
    }
}
