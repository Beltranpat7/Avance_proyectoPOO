package controllers;

import models.Sucursal;
import services.SucursalService;
import services.UsuarioService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/RegistroSucursalController")
public class RegistroSucursalController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener la lista de IDs de usuarios (gerentes) desde la base de datos
        UsuarioService usuarioService = new UsuarioService();
        List<Integer> idsUsuarios = usuarioService.obtenerIdsUsuariosDesdeBD();

        // Pasar la lista de IDs de usuarios a la JSP
        request.setAttribute("idsUsuarios", idsUsuarios);

        // Otros campos del formulario
        String nombreSucursal = request.getParameter("nombreSucursal");
        String direccion = request.getParameter("direccion");
        String telefono = request.getParameter("telefono");

        // Obtener el ID del usuario seleccionado desde el formulario
        int idUsuario = Integer.parseInt(request.getParameter("idUsuario"));

        // Crear la sucursal
        Sucursal sucursal = new Sucursal();
        sucursal.setNombreSucursal(nombreSucursal);
        sucursal.setDireccion(direccion);
        sucursal.setTelefono(telefono);
        sucursal.setIdUsuario(idUsuario);

        // Guardar la sucursal en la base de datos
        SucursalService sucursalService = new SucursalService();
        boolean registroExitoso = sucursalService.registrarSucursal(sucursal);

        if (registroExitoso) {
            response.sendRedirect("inicio.jsp"); // Redirige a la página principal si el registro fue exitoso
        } else {
            response.sendRedirect("registroSucursal.jsp"); // Vuelve a la página de registro en caso de error
        }
    }
}
