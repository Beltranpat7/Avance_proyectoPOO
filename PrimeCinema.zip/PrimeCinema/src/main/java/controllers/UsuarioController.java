package controllers;

import models.Usuario;
import services.UsuarioService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/UsuarioController")
public class UsuarioController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String dui = request.getParameter("dui");
        String direccion = request.getParameter("direccion");
        String telefono = request.getParameter("telefono");
        String correoElectronico = request.getParameter("correoElectronico");
        String contrasena = request.getParameter("contrasena");

        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setApellido(apellido);
        usuario.setDui(dui);
        usuario.setDireccion(direccion);
        usuario.setNumeroTelefono(telefono);
        usuario.setCorreoElectronico(correoElectronico);
        usuario.setContrasena(contrasena);

        UsuarioService usuarioService = new UsuarioService();
        boolean registroExitoso = usuarioService.registrarUsuario(usuario);

        if (registroExitoso) {
            response.sendRedirect("index.jsp"); // Redirige a la página principal si el registro fue exitoso
        } else {
            response.sendRedirect("registrarUsuario.jsp"); // Vuelve a la página de registro en caso de error
        }
    }
}
