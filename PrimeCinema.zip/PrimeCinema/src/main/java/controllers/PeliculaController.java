package controllers;

import models.Clasificacion;
import models.Formato;
import models.Genero;
import models.Pelicula;
import services.PeliculaService;
import services.GeneroService;
import services.ClasificacionService;
import services.FormatoService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/PeliculaController")
public class PeliculaController extends HttpServlet {
    private PeliculaService peliculaService = new PeliculaService();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        float duracion = Float.parseFloat(request.getParameter("duracion"));
        int idGenero = Integer.parseInt(request.getParameter("idGenero"));
        int idFormato = Integer.parseInt(request.getParameter("idFormato"));
        int idClasificacion = Integer.parseInt(request.getParameter("idClasificacion"));

        Pelicula pelicula = new Pelicula();
        pelicula.setNombre(nombre);
        pelicula.setDuracion(duracion);
        pelicula.setIdGenero(idGenero);
        pelicula.setIdFormato(idFormato);
        pelicula.setIdClasificacion(idClasificacion);

        boolean registroExitoso = peliculaService.registrarPelicula(pelicula);

        if (registroExitoso) {
            response.getWriter().println("Pelicula registrada con éxito");
        } else {
            response.getWriter().println("Error al registrar la película");
        }
    }
}
