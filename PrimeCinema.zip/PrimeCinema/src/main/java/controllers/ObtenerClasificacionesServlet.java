package controllers;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.ClasificacionService;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

@WebServlet("/ObtenerClasificacionesServlet")
public class ObtenerClasificacionesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ClasificacionService clasificacionService = new ClasificacionService();
        List<Map<String, Object>> clasificaciones = clasificacionService.obtenerClasificacionesDesdeBD();

        Gson gson = new Gson();
        String clasificacionesJson = gson.toJson(clasificaciones);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(clasificacionesJson);
    }
}
