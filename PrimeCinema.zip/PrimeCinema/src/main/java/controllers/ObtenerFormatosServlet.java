package controllers;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.FormatoService;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

@WebServlet("/ObtenerFormatosServlet")
public class ObtenerFormatosServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        FormatoService formatoService = new FormatoService();
        List<Map<String, Object>> formatos = formatoService.obtenerFormatosDesdeBD();

        Gson gson = new Gson();
        String formatosJson = gson.toJson(formatos);

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(formatosJson);
    }
}
